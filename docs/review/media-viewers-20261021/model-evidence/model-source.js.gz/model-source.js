const KEEL_MODEL_MEDIA_TYPES=["model/gltf-binary","model/gltf+json","model/obj"],KEEL_GLTF_SUPPORTED_EXTENSIONS=["KHR_materials_unlit","KHR_texture_transform","KHR_mesh_quantization","KHR_lights_punctual","KHR_materials_clearcoat","KHR_materials_dispersion","KHR_materials_sheen","KHR_materials_transmission","KHR_materials_volume","KHR_materials_ior","KHR_materials_emissive_strength","KHR_materials_specular","KHR_materials_iridescence","KHR_materials_anisotropy","EXT_mesh_gpu_instancing","EXT_texture_webp","EXT_texture_avif"];
function resolveKeelModelResourcePath(base, uri) {
    if (!uri || /[\\?#\u0000-\u001f]/u.test(uri) || /^(?:[a-z][a-z0-9+.-]*:|\/)/iu.test(uri))
        throw new TypeError("Model dependencies require exact relative verified paths.");
    let decoded;
    try {
        decoded = decodeURIComponent(uri);
    }
    catch {
        throw new TypeError("Malformed model dependency URI.");
    }
    if (/[\\?#%\u0000-\u001f]/u.test(decoded) || /^(?:[a-z][a-z0-9+.-]*:|\/)/iu.test(decoded))
        throw new TypeError("Ambiguous model dependency URI.");
    const parts = base.split("/").slice(0, -1);
    for (const part of decoded.split("/")) {
        if (part === "." || part === "")
            continue;
        if (part === "..") {
            if (!parts.length)
                throw new TypeError("Model dependency escapes its verified resource root.");
            parts.pop();
        }
        else
            parts.push(part);
    }
    if (!parts.length)
        throw new TypeError("Empty model dependency path.");
    return parts.join("/");
}
function decodeKeelModelDataURI(uri) {
    const match = /^data:(?:application\/octet-stream|application\/gltf-buffer|image\/(?:png|jpeg|webp|avif));base64,([A-Za-z0-9+/]*={0,2})$/u.exec(uri);
    if (!match || !match[1] || match[1].length % 4 !== 0)
        throw new TypeError("Model embedded dependencies require a canonical supported Base64 data URI.");
    const raw = atob(match[1]);
    if (btoa(raw) !== match[1])
        throw new TypeError("Noncanonical model data URI.");
    return Uint8Array.from(raw, character => character.charCodeAt(0));
}
function parseKeelModelGLTF(source, mediaType) {
    const decoder = new TextDecoder("utf-8", { fatal: true });
    if (mediaType === "model/gltf+json")
        return { json: JSON.parse(decoder.decode(source)) };
    if (source.length < 20)
        throw new TypeError("Malformed GLB header or length.");
    const view = new DataView(source.buffer, source.byteOffset, source.byteLength);
    if (view.getUint32(0, true) !== 0x46546c67 || view.getUint32(4, true) !== 2 || view.getUint32(8, true) !== source.length)
        throw new TypeError("Malformed GLB header or length.");
    let at = 12, json, binary;
    while (at < source.length) {
        if (at + 8 > source.length)
            throw new TypeError("Truncated GLB chunk.");
        const size = view.getUint32(at, true), kind = view.getUint32(at + 4, true), end = at + 8 + size;
        if (size % 4 || end > source.length)
            throw new TypeError("Malformed GLB chunk boundary.");
        if (kind === 0x4e4f534a) {
            if (at !== 12 || json)
                throw new TypeError("GLB requires one first JSON chunk.");
            json = JSON.parse(decoder.decode(source.subarray(at + 8, end)));
        }
        else if (kind === 0x004e4942) {
            if (!json || binary)
                throw new TypeError("GLB has an ambiguous binary chunk.");
            binary = source.subarray(at + 8, end);
        }
        else
            throw new TypeError("Unsupported GLB chunk cannot be silently discarded.");
        at = end;
    }
    if (!json)
        throw new TypeError("GLB JSON is missing.");
    return binary === undefined ? { json } : { json, binary };
}
function keelModelMTLTexturePath(value) {
    const items = value.trim().split(/\s+/u), arities = { "-bm": 1, "-mm": 2, "-s": 3, "-o": 3 };
    for (let at = 0; at < items.length;) {
        const token = items[at];
        if (token.startsWith("-")) {
            const count = arities[token];
            if (count === undefined || at + count >= items.length || !items.slice(at + 1, at + count + 1).every(item => Number.isFinite(Number(item))))
                throw new TypeError("Unsupported or malformed MTL texture option.");
            items.splice(at, count + 1);
        }
        else
            at++;
    }
    return items.join(" ");
}
function inspectKeelModelMedia(entry, assets = []) {
    if (!KEEL_MODEL_MEDIA_TYPES.includes(entry.mediaType))
        throw new TypeError("Unsupported model media type.");
    const byPath = new Map(), ids = new Set();
    for (const resource of [entry, ...assets]) {
        if (!resource.source.length || ids.has(resource.id))
            throw new TypeError("Empty or duplicate model resource identity.");
        ids.add(resource.id);
        for (const alias of [resource.id, ...(resource.aliases ?? [])]) {
            const path = resolveKeelModelResourcePath("", alias);
            if (byPath.has(path))
                throw new TypeError("Ambiguous or duplicate model resource path " + path);
            byPath.set(path, resource);
        }
    }
    const entryPath = resolveKeelModelResourcePath("", entry.aliases?.[0] ?? entry.id), used = new Set(), libraries = [], required = [];
    const resolve = (base, uri) => {
        if (uri.startsWith("data:"))
            return decodeKeelModelDataURI(uri);
        const path = resolveKeelModelResourcePath(base, uri), found = byPath.get(path);
        if (!found || found === entry)
            throw new TypeError("Missing verified model dependency " + path);
        used.add(found.id);
        return found.source;
    };
    if (entry.mediaType === "model/obj") {
        const text = new TextDecoder("utf-8", { fatal: true }).decode(entry.source), names = new Set();
        if (!/^v\s/mu.test(text) || !/^f\s/mu.test(text))
            throw new TypeError("OBJ has no complete vertex/face geometry.");
        for (const match of text.matchAll(/^\s*mtllib\s+(.+)$/gmu))
            for (const uri of match[1].trim().split(/\s+/u)) {
                const path = resolveKeelModelResourcePath(entryPath, uri), library = byPath.get(path);
                resolve(entryPath, uri);
                if (!library || libraries.includes(library.id))
                    throw new TypeError("Ambiguous OBJ material library.");
                libraries.push(library.id);
                const source = new TextDecoder("utf-8", { fatal: true }).decode(library.source);
                for (const line of source.split(/\r?\n/u)) {
                    const match = /^\s*(\S+)\s+(.*?)\s*$/u.exec(line);
                    if (!match)
                        continue;
                    const key = match[1].toLowerCase(), value = match[2];
                    if (key === "newmtl") {
                        if (names.has(value))
                            throw new TypeError("Ambiguous OBJ material name " + value);
                        names.add(value);
                    }
                    if (key.startsWith("map_") || key === "bump" || key === "disp" || key === "norm")
                        resolve(path, keelModelMTLTexturePath(value));
                }
            }
        for (const match of text.matchAll(/^\s*usemtl\s+(.+)$/gmu))
            if (!names.has(match[1].trim()))
                throw new TypeError("Missing verified OBJ material " + match[1].trim());
    }
    else {
        const { json, binary } = parseKeelModelGLTF(entry.source, entry.mediaType);
        if (!json || json.asset?.version !== "2.0" || !Array.isArray(json.scenes) || !json.scenes.length || !Array.isArray(json.meshes) || !json.meshes.length)
            throw new TypeError("A complete glTF2 scene and geometry are required.");
        for (const extension of [...(json.extensionsUsed ?? []), ...(json.extensionsRequired ?? [])]) {
            if (typeof extension !== "string" || !KEEL_GLTF_SUPPORTED_EXTENSIONS.includes(extension))
                throw new TypeError("Unsupported glTF extension requires an exact registered decoder/adapter: " + extension);
        }
        required.push(...(json.extensionsRequired ?? []));
        for (const [index, buffer] of (json.buffers ?? []).entries()) {
            const bytes = buffer.uri === undefined && index === 0 ? binary : typeof buffer.uri === "string" ? resolve(entryPath, buffer.uri) : undefined;
            if (!bytes || !Number.isSafeInteger(buffer.byteLength) || buffer.byteLength < 1 || bytes.length < buffer.byteLength || bytes.length - buffer.byteLength > (buffer.uri === undefined ? 3 : 0))
                throw new TypeError("Model buffer length does not match its original bytes.");
        }
        for (const image of json.images ?? [])
            if (typeof image.uri === "string")
                resolve(entryPath, image.uri);
            else if (!Number.isSafeInteger(image.bufferView))
                throw new TypeError("Model image requires a verified URI or bufferView.");
    }
    if (assets.some(asset => !used.has(asset.id)))
        throw new TypeError("Extra model resources are not part of the exact dependency closure.");
    return Object.freeze({ format: entry.mediaType === "model/obj" ? "obj" : "gltf", entryPath, dependencyIds: Object.freeze([...used]), materialLibraryIds: Object.freeze(libraries), requiredExtensions: Object.freeze(required), sourceByteLength: [entry, ...assets].reduce((n, r) => n + r.source.length, 0) });
}

const entry=globalThis.__KEEL_ENTRY__,content=globalThis.__KEEL_CONTENT__,modules=globalThis.__KEEL_MODULES__,root=document.getElementById("keel-asset-display");
if(!entry||!content||!root||!modules)throw new Error("KEEL model viewer requires its exact verified entry and module closure.");
const THREE=modules["three-r180-module"];
if(String(THREE?.REVISION)!=="180")throw new Error("KEEL model viewer requires pinned Three r180.");
const records=content.resources().filter(r=>r.role==="entrypoint"||r.role==="asset"),resources=records.map(r=>({id:r.id,mediaType:r.mediaType,aliases:r.aliases??[r.name],source:content.bytes(r.id)}));
const original=resources.find(r=>r.id===entry.id),assets=resources.filter(r=>r.id!==entry.id),profile=inspectKeelModelMedia(original,assets),byPath=new Map();
for(const r of resources)for(const alias of [r.id,...r.aliases])byPath.set(resolveKeelModelResourcePath("",alias),r);
const resolve=uri=>{const found=byPath.get(resolveKeelModelResourcePath("",uri));if(!found)throw new Error("Undeclared verified model dependency "+uri);return found};
let renderer,scene,model,camera,mixer,clips=[],scenes=[],sourceCameras=[],action,playing=true,disposed=false,last=performance.now(),frame=0;
const manager=new THREE.LoadingManager();
manager.setURLModifier(uri=>uri.startsWith("blob:")||uri.startsWith("data:")?uri:content.url(resolve(uri).id));
const ready=(async()=>{
 let result;
 if(profile.format==="gltf"){
  const GLTFLoader=modules["three-r180-gltf-loader"]?.GLTFLoader;if(!GLTFLoader)throw new Error("Missing exact verified GLTFLoader.");
  const loader=new GLTFLoader(manager);
  loader.register(parser=>{parser.textureLoader=new THREE.TextureLoader(manager);parser.fileLoader={load:(uri,onLoad,_progress,onError)=>{try{const b=uri.startsWith("data:")?decodeKeelModelDataURI(uri):content.bytes(resolve(uri).id);queueMicrotask(()=>onLoad(b.slice().buffer))}catch(error){queueMicrotask(()=>onError(error))}};return{name:"KEEL_verified_memory_only"}});
  const bytes=original.source;result=await loader.parseAsync(entry.mediaType==="model/gltf+json"?new TextDecoder("utf-8",{fatal:true}).decode(bytes):bytes.slice().buffer,profile.entryPath.split("/").slice(0,-1).join("/")+(profile.entryPath.includes("/")?"/":""));
  scenes=result.scenes;model=result.scene;clips=result.animations;sourceCameras=result.cameras;
 }else{
  const OBJLoader=modules["three-r180-obj-loader"]?.OBJLoader;if(!OBJLoader)throw new Error("Missing exact verified OBJLoader.");
  const loader=new OBJLoader(manager),creators=[],materials=new Map();let pending=0,done,failed;const textures=new Promise((resolve,reject)=>{done=resolve;failed=reject});
  manager.onStart=()=>{pending++};manager.onLoad=()=>done();manager.onError=uri=>failed(new Error("Verified model texture decode failed: "+uri));
  if(profile.materialLibraryIds.length){
   const MTLLoader=modules["three-r180-mtl-loader"]?.MTLLoader;if(!MTLLoader)throw new Error("Missing exact verified MTLLoader.");
   for(const id of profile.materialLibraryIds){const r=resources.find(r=>r.id===id),path=r.aliases[0]??r.id,base=path.split("/").slice(0,-1).join("/")+(path.includes("/")?"/":""),creator=new MTLLoader(manager).parse(new TextDecoder("utf-8",{fatal:true}).decode(r.source),base);creators.push(creator);for(const name of Object.keys(creator.materialsInfo)){if(materials.has(name))throw new Error("Ambiguous verified OBJ material "+name);materials.set(name,creator)}creator.preload()}
   loader.setMaterials({create:name=>{const creator=materials.get(name);if(!creator)throw new Error("Undeclared verified OBJ material "+name);return creator.create(name)}});
  }
  if(pending)await textures;model=loader.parse(new TextDecoder("utf-8",{fatal:true}).decode(original.source));scenes=[model];
 }
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
 renderer.domElement.setAttribute("aria-label",entry.name||"Verified KEEL model");Object.assign(renderer.domElement.style,{display:"block",width:"100%",height:"100%"});root.replaceChildren(renderer.domElement);root.dataset.modelState="ready";
 scene=new THREE.Scene();scene.background=new THREE.Color(/^#?[0-9a-f]{6}$/i.test(entry.background_color??"")?"#"+entry.background_color.replace(/^#/,""):"#05060b");scene.add(new THREE.HemisphereLight(0xffffff,0x444444,2));const sun=new THREE.DirectionalLight(0xffffff,2);sun.position.set(3,5,4);scene.add(sun);
 function mount(next){if(mixer){mixer.stopAllAction();mixer.uncacheRoot(model)}if(model?.parent===scene)scene.remove(model);model=next;scene.add(model);model.updateMatrixWorld(true);mixer=new THREE.AnimationMixer(model);action=undefined;if(clips.length){action=mixer.clipAction(clips[0]);action.play()}camera=undefined;model.traverse(n=>{if(!camera&&n.isCamera)camera=n});if(!camera){const bounds=new THREE.Box3().setFromObject(model),center=bounds.getCenter(new THREE.Vector3()),size=bounds.getSize(new THREE.Vector3()),radius=Math.max(size.x,size.y,size.z,.01);camera=new THREE.PerspectiveCamera(40,1,Math.max(radius/1000,.001),radius*1000);camera.position.set(center.x,center.y,center.z+radius*1.8);camera.lookAt(center)}last=performance.now()}
 mount(model);
 const draw=now=>{if(disposed)return;const width=Math.max(1,root.clientWidth),height=Math.max(1,root.clientHeight);renderer.setSize(width,height,false);if(camera.isPerspectiveCamera){camera.aspect=width/height;camera.updateProjectionMatrix()}if(playing)mixer.update(Math.max(0,(now-last)/1000));last=now;renderer.render(scene,camera);frame=requestAnimationFrame(draw)};frame=requestAnimationFrame(draw);
 return Object.freeze({sceneCount:scenes.length,clipNames:Object.freeze(clips.map(c=>c.name)),sourceCameraCount:sourceCameras.length,selectScene:index=>{if(!Number.isInteger(index)||!scenes[index])throw new RangeError("Unknown original model scene");mount(scenes[index])}});
})();
const modelViewer=Object.freeze({protocol:"keel-model-viewer@1",ready,
 play:async(index=0)=>{await ready;const selected=typeof index==="string"?clips.find(c=>c.name===index):clips[index];if(!selected)throw new RangeError("Unknown original model animation");mixer.stopAllAction();action=mixer.clipAction(selected);action.reset().play();playing=true;last=performance.now()},
 pause:async()=>{await ready;playing=false},seek:async seconds=>{await ready;if(!Number.isFinite(seconds)||seconds<0)throw new RangeError("Model animation time must be nonnegative");mixer.setTime(seconds);model.updateMatrixWorld(true);renderer.render(scene,camera)},
 dispose:async()=>{await ready;if(disposed)return;disposed=true;cancelAnimationFrame(frame);mixer.stopAllAction();for(const originalScene of scenes)originalScene.traverse(n=>{n.geometry?.dispose();for(const material of Array.isArray(n.material)?n.material:n.material?[n.material]:[]){for(const value of Object.values(material))if(value?.isTexture)value.dispose();material.dispose()}});renderer.dispose();root.replaceChildren()}});
ready.catch(error=>{root.dataset.modelState="failed";setTimeout(()=>{throw error},0)});
export {modelViewer};
